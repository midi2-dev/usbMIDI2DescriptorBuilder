// Paste the results from https://midi2-dev.github.io/usbMIDI2DescriptorBuilder/protozoa.html in this file



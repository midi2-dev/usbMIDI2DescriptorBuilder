//
// Created by andrew on 8/22/25.
//

#ifndef FUNCTIONBLOCKHELPER_H
#define FUNCTIONBLOCKHELPER_H

#define MIDI1_BAUD_RATE 31250

#include <cmath>
//DIN Support
#include "pico/stdio/driver.h"
#include "hardware/pio.h"

#include <uart_rx.pio.h>
#include <uart_tx.pio.h>
#include <vector>

#include "../../lib/AM_MIDI2.0Lib/include/midiCIMessageCreate.h"
#include "../../lib/AM_MIDI2.0Lib/include/midiCIProcessor.h"
#include "ump_device.h"

uint8_t sxPos=0;
std::array<uint8_t, 6> sx;

PIO pio = pio0 ;
uint smRx = 0;
uint smTx = 1;

uint8_t midiProtocol = 0x00;

class profile{

public:
    uint8_t profileid[5] = {0,0,0,0,0} ;
    uint8_t channel = 0; //0x7F = FB, 0x7E = Group
	uint8_t numOfChannels = 1;
    uint8_t umpGroupOffset = 0;
    bool enabled = false;
};

class umpFunctionBlock{

public:
    uint8_t idx = 0;
    uint8_t groupStart = 0;
    uint8_t numOfGroups = 16;
    bool active = true;
    uint8_t direction = 3;
    bool uiSender = true;
    bool uiReceiver = true;
    uint8_t maxS8Streams = 0;
    uint8_t midiCISupport = 0;
    bool midi1Only = false;
    midiCIProcessor MIDICIHandler;
    uint32_t MUID = 0 ;
    bool isProcMIDICI = false;
    std::string name;
    std::vector<profile> profiles;
};


void midiendpoint(uint8_t majVer, uint8_t minVer, uint8_t filter){
	if(filter & 0b1){
		std::array<uint32_t, 4> UMP = UMPMessage::mtFMidiEndpointInfoNotify(
				1, true, true, false, false);
		tud_ump_write(0,UMP.data(),4);
	}
	if(filter & 0b10){
		std::array<uint32_t, 4> UMP = UMPMessage::mtFMidiEndpointDeviceInfoNotify(
				{DEVICE_MFRID}, {DEVICE_FAMID}, {DEVICE_MODELID}, {DEVICE_VERSIONID});
		tud_ump_write(0,UMP.data(),4);

	}
	if(filter & 0b100) {
		int epNameLength = strlen(DEVICE_ENDPOINTNAME);
		for(uint8_t offset=0; offset<epNameLength; offset+=14) {
			std::array<uint32_t, 4> UMP = UMPMessage::mtFMidiEndpointTextNotify(
					MIDIENDPOINT_NAME_NOTIFICATION, offset, (uint8_t *) DEVICE_ENDPOINTNAME,
					epNameLength);
			tud_ump_write(0,UMP.data(),4);
		}
	}
	if(filter & 0b1000) {
		int len = 2 * PICO_UNIQUE_BOARD_ID_SIZE_BYTES + 1;
		uint8_t buff[len];
		pico_get_unique_board_id_string((char *)buff, len);
		for(uint8_t offset=0; offset<len; offset+=14) {
			std::array<uint32_t, 4> UMP = UMPMessage::mtFMidiEndpointTextNotify(
					MIDIENDPOINT_PRODID_NOTIFICATION, offset, (uint8_t *) buff,len);
			tud_ump_write(0,UMP.data(),4);
		}
	}
	if (filter & 0b10000) {
		std::array<uint32_t, 4> UMP = UMPMessage::mtFNotifyProtocol(
					midiProtocol, 0,0);
		tud_ump_write(0,UMP.data(),4);
	}
}

void streamRequest(uint8_t protocol, bool jrrx, bool jrtx) {
	midiProtocol = protocol;
	std::array<uint32_t, 4> UMP = UMPMessage::mtFNotifyProtocol(
					midiProtocol, 0,0);
	tud_ump_write(0,UMP.data(),4);
}

uint32_t randomMuid(){
    return (rand() % static_cast<uint32_t>(0xFFFFEFF + 1));
}

void sendOutSysex(uint8_t group, uint8_t *sysex ,uint16_t length, uint8_t state){
    if (state < 2) {
        sxPos=0;
    }
    for (int i = 0; i < length; i++) {
        sx[sxPos++]=sysex[i] & 0x7F;
        if(sxPos == 6){
            std::array<uint32_t, 2> UMP = UMPMessage::mt3Sysex7(group, state < 2 && i < 6 ? 1 : 2, 6, sx);
            tud_ump_write(0,UMP.data(),2);
            sxPos=0;
        }
    }
    if (state == 0 || state == 3) {
        std::array<uint32_t, 2> UMP = UMPMessage::mt3Sysex7(group, length < 7 && state==0 ? 0 : 3, sxPos, sx);
        tud_ump_write(0,UMP.data(),2);
    }
}



bool checkMUIDCallback(uint8_t umpGroup, uint32_t muid, void * refpoint){
	umpFunctionBlock * fb = (umpFunctionBlock *)refpoint;
	if (umpGroup >= fb->groupStart && umpGroup < fb->groupStart + fb->numOfGroups) {
		if(fb->MUID==muid) return true;
	}

	return false;
}


void recvDiscovery(struct MIDICI ciDetails, std::array<uint8_t, 3> manuId, std::array<uint8_t, 2> familyId,
						   std::array<uint8_t, 2> modelId, std::array<uint8_t, 4> version, uint8_t remoteciSupport,
						   uint16_t remotemaxSysex, uint8_t outputPathId
){
	//All MIDI-CI Devices shall reply to a Discovery message
	uint8_t sysexBuffer[64];
	umpFunctionBlock * fb = (umpFunctionBlock *)ciDetails.refpoint;
	int len = CIMessage::sendDiscoveryReply(sysexBuffer, 0x02, fb->MUID, ciDetails.remoteMUID,
											{DEVICE_MFRID}, {DEVICE_FAMID}, {DEVICE_MODELID},
											{DEVICE_VERSIONID},fb->midiCISupport,
											512, outputPathId,
											fb->idx //fbIdx
	);
	sendOutSysex(ciDetails.umpGroup, sysexBuffer ,len, 0);
}

void handleEndpointInfo(MIDICI ciDetails, uint8_t status) {
	if (status==0x00) {
		umpFunctionBlock * fb = (umpFunctionBlock *)ciDetails.refpoint;
		int plen = 2 * PICO_UNIQUE_BOARD_ID_SIZE_BYTES + 1;
		uint8_t buff[plen];
		pico_get_unique_board_id_string((char *)buff, plen);
		uint8_t sysexBuffer[128];
		int len = CIMessage::sendEndpointInfoReply(sysexBuffer, 0x02, fb->MUID,ciDetails.remoteMUID,status,plen, buff);
		sendOutSysex(ciDetails.umpGroup, sysexBuffer ,len, 0);
	}
}

void invalidMUID(struct MIDICI ciDetails, uint32_t terminateMuid) {
	umpFunctionBlock * fb = (umpFunctionBlock *)ciDetails.refpoint;
	if (fb->MUID == terminateMuid) {
		fb->MUID = randomMuid();
		uint8_t sysexBuffer[64];
		int len = CIMessage::sendDiscoveryRequest(sysexBuffer, 0x02, fb->MUID,
											{DEVICE_MFRID}, {DEVICE_FAMID}, {DEVICE_MODELID},
											{DEVICE_VERSIONID},fb->midiCISupport, 512, 0
		);
		sendOutSysex(fb->groupStart, sysexBuffer ,len, 0);
	}
}



void handleProfileInquiryByDeviceID(MIDICI ciDetails, uint8_t channel, uint8_t umpGroup, bool forceSend) {
	umpFunctionBlock * fb = (umpFunctionBlock *)ciDetails.refpoint;
	uint8_t profilesEnabledLen = 0;
	uint8_t profilesDisabledLen = 0;
	uint8_t profilesEnabled[25];
	uint8_t profilesDisabled[25];

	for (auto & element : fb->profiles) {
		if (
			(channel == 0x7F && channel == element.channel)
			||
			(channel == element.channel && umpGroup == element.umpGroupOffset + fb->groupStart)
			){
			if (element.enabled) {
				std::copy(element.profileid, element.profileid+5, profilesEnabled + (profilesEnabledLen*5));
				profilesEnabledLen++;
			}else {
				std::copy(element.profileid, element.profileid+5, profilesDisabled + (profilesDisabledLen*5));
				profilesDisabledLen++;
			}
		}
	}
	if (forceSend || profilesEnabledLen>0 || profilesDisabledLen>0) {
		uint8_t sysexBuffer[128];
		int len = CIMessage::sendProfileListResponse(sysexBuffer, 0x02, fb->MUID, ciDetails.remoteMUID,
			channel, profilesEnabledLen, profilesEnabled, profilesDisabledLen, profilesDisabled
		);
		sendOutSysex(fb->groupStart, sysexBuffer ,len, 0);
	}
}

void handleProfileInquiry(MIDICI ciDetails) {
	umpFunctionBlock * fb = (umpFunctionBlock *)ciDetails.refpoint;
	if (ciDetails.deviceId != 0x7F) {
		handleProfileInquiryByDeviceID(ciDetails, ciDetails.deviceId, ciDetails.umpGroup, true);
	}else {
		//Go through every channel and find something or not
		for (uint8_t gr = fb->groupStart; gr < fb->numOfGroups + fb->groupStart; gr++) {
			for (uint8_t ch = 0; ch < 16; ch++) {
				handleProfileInquiryByDeviceID(ciDetails, ch, gr, false);
			}
			handleProfileInquiryByDeviceID(ciDetails, 0x7E, gr, false);
		}

		handleProfileInquiryByDeviceID(ciDetails, 0x7F, ciDetails.umpGroup, true);
	}
}



void handleProfileOn(MIDICI ciDetails, std::array<uint8_t, 5> profile, uint8_t numberOfChannels) {
	umpFunctionBlock * fb = (umpFunctionBlock *)ciDetails.refpoint;

	for (auto & element : fb->profiles) {
		if (
			(ciDetails.deviceId == 0x7F && ciDetails.deviceId == element.channel)
			||
			(ciDetails.deviceId == element.channel % 16 && ciDetails.umpGroup == (uint8_t)floor(element.channel/16))
			){
			element.enabled = true;
			uint8_t sysexBuffer[64];
			std::array<uint8_t, 5> profileid;

			// Copy elements from c_array to std_array
			std::copy(std::begin(element.profileid), std::end(element.profileid), std::begin(profileid));

			int len = CIMessage::sendProfileEnabled(sysexBuffer, 0x02, fb->MUID, ciDetails.remoteMUID,
												ciDetails.deviceId, profileid, element.numOfChannels);
			sendOutSysex(ciDetails.umpGroup, sysexBuffer ,len, 0);
			}
	}
}
void handleProfileOff(MIDICI ciDetails, std::array<uint8_t, 5> profile) {
	umpFunctionBlock * fb = (umpFunctionBlock *)ciDetails.refpoint;

	for (auto & element : fb->profiles) {
		if (
			(ciDetails.deviceId == 0x7F && ciDetails.deviceId == element.channel)
			||
			(ciDetails.deviceId == element.channel % 16 && ciDetails.umpGroup == (uint8_t)floor(element.channel/16))
			){
			element.enabled = false;
			uint8_t sysexBuffer[64];
			std::array<uint8_t, 5> profileid;

			// Copy elements from c_array to std_array
			std::copy(std::begin(element.profileid), std::end(element.profileid), std::begin(profileid));

			int len = CIMessage::sendProfileDisabled(sysexBuffer, 0x02, fb->MUID, ciDetails.remoteMUID,
												ciDetails.deviceId, profileid, element.numOfChannels);
			sendOutSysex(ciDetails.umpGroup, sysexBuffer ,len, 0);
			}
	}
}

void pio_rx_init(PIO piorx, uint smrx) {
	// Set up the state machine we're going to use to receive them.
	uint offset = pio_add_program(piorx, &uart_rx_program);
	uart_rx_program_init(piorx, smrx, offset, 13, MIDI1_BAUD_RATE);
}
void pio_tx_init(PIO piotx, uint smtx) {
	uint offset = pio_add_program(piotx, &uart_tx_program);
	uart_tx_program_init(piotx, smtx, offset, 12, MIDI1_BAUD_RATE);
}







#endif //AMENOTE_FUNCTIONBLOCKHELPER_H
//
// Created by andrew on 10/1/25.
//

#ifndef AMENOTE_USB_DEV_DESCRIPTORS_H
#define AMENOTE_USB_DEV_DESCRIPTORS_H


//
// Copy the data created by https://midi2-dev.github.io/usbMIDI2DescriptorBuilder/ into this file
//


#endif //AMENOTE_USB_DEV_DESCRIPTORS_H